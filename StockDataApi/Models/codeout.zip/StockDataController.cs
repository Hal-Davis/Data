﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StockDataApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace StockDataApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockDataController : ControllerBase
    {
        private readonly StockDataContext _context;
        private readonly ILogger<StockDataController> _logger;

        public StockDataController(StockDataContext context, ILogger<StockDataController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // ✅ Get Latest Stock Data
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StockData>>> GetStockData()
        {
            return await _context.StockData
                .OrderByDescending(s => s.Date)
                .Take(100)
                .AsNoTracking()
                .ToListAsync();
        }

        // ✅ Get Moving Average (SMA)
        [HttpGet("moving-average/{symbol}/{days}")]
        public async Task<ActionResult<double>> GetMovingAverage(string symbol, int days)
        {
            var stockPrices = await _context.StockData
                .Where(s => s.Symbol == symbol)
                .OrderByDescending(s => s.Date)
                .Take(days)
                .Select(s => s.ClosePrice ?? 0) // Handle null values
                .ToListAsync();

            if (!stockPrices.Any()) return NotFound("No data available");

            return Ok(stockPrices.Average());
        }

        // ✅ Get Exponential Moving Average (EMA)
        [HttpGet("ema/{symbol}/{days}")]
        public async Task<ActionResult<double>> GetEMA(string symbol, int days)
        {
            var stockPrices = await _context.StockData
                .Where(s => s.Symbol == symbol)
                .OrderByDescending(s => s.Date)
                .Take(days)
                .Select(s => s.ClosePrice ?? 0)
                .ToListAsync();

            if (!stockPrices.Any()) return NotFound("No data available");

            return Ok(CalculateEMA(stockPrices, days));
        }

        private double CalculateEMA(List<double> prices, int period)
        {
            if (prices.Count < period) return 0;

            double multiplier = 2.0 / (period + 1);
            double ema = prices.First();

            foreach (var price in prices.Skip(1))
            {
                ema = (price - ema) * multiplier + ema;
            }

            return ema;
        }

        // ✅ Get RSI
        [HttpGet("rsi/{symbol}/{days}")]
        public async Task<ActionResult<double>> GetRSI(string symbol, int days)
        {
            var stockPrices = await _context.StockData
                .Where(s => s.Symbol == symbol)
                .OrderByDescending(s => s.Date)
                .Take(days + 1)
                .Select(s => s.ClosePrice ?? 0)
                .ToListAsync();

            if (stockPrices.Count < days) return NotFound("Not enough data");

            return Ok(CalculateRSI(stockPrices));
        }

        private double CalculateRSI(List<double> prices)
        {
            double gain = 0, loss = 0;

            for (int i = 1; i < prices.Count; i++)
            {
                double change = prices[i] - prices[i - 1];
                if (change > 0) gain += change;
                else loss -= change;
            }

            double avgGain = gain / prices.Count;
            double avgLoss = loss / prices.Count;
            if (avgLoss == 0) return 100;

            double rs = avgGain / avgLoss;
            return 100 - (100 / (1 + rs));
        }

        // ✅ Get Stock Symbols
        [HttpGet("symbols")]
        public async Task<ActionResult<List<string>>> GetDistinctSymbols()
        {
            return await _context.StockData
                .Select(s => s.Symbol ?? "")
                .Distinct()
                .OrderBy(s => s)
                .AsNoTracking()
                .ToListAsync();
        }

        [HttpGet("decision/{symbol}")]
        public async Task<ActionResult<string>> GetBuySellDecision(string symbol)
        {
            // ✅ Fetch stock signals, ensuring no duplicate dates
            var latestStockSignals = await _context.StockSignals
                .Where(ss => ss.Symbol == symbol)
                .OrderByDescending(ss => ss.Date)
                .GroupBy(ss => ss.Date) // ✅ Group by Date to prevent duplicate keys
                .Select(g => g.First()) // ✅ Take the most recent entry per date
                .ToDictionaryAsync(ss => ss.Date);

            // ✅ Fetch stock data
            var stockData = await _context.StockData
                .Where(sd => sd.Symbol == symbol)
                .OrderByDescending(sd => sd.Date)
                .Take(50)
                .ToListAsync();

            if (!stockData.Any()) return NotFound("Not enough data");

            // ✅ Get the latest stock data entry
            var latestEntry = stockData.FirstOrDefault();
            if (latestEntry == null || !latestStockSignals.TryGetValue(Convert.ToDateTime(latestEntry.Date), out var signal))
            {
                _logger.LogWarning($"No valid data available for {symbol} on {latestEntry?.Date}");
                return NotFound("No valid data available");
            }

            // ✅ Compute buy/sell decision
            bool buySignal = signal.SMA_10 > signal.SMA_50 && signal.RSI < 30;
            bool sellSignal = signal.SMA_10 < signal.SMA_50 && signal.RSI > 70;

            return Ok(buySignal ? "BUY" : sellSignal ? "SELL" : "HOLD");
        }

        [HttpGet("momentum/{symbol}")]
        public async Task<ActionResult<int>> GetMomentumScore(string symbol)
        {
            var latestStockSignals = await _context.StockSignals
                .Where(ss => ss.Symbol == symbol)
                .OrderByDescending(ss => ss.Date)
                .GroupBy(ss => ss.Date) // Prevent duplicate dates
                .Select(g => g.First()) // Take latest per date
                .ToListAsync();

            if (!latestStockSignals.Any()) return NotFound("No stock signals available.");

            var stockData = await _context.StockData
                .Where(sd => sd.Symbol == symbol)
                .OrderByDescending(sd => sd.Date)
                .Take(50)
                .ToListAsync();

            if (!stockData.Any()) return NotFound("No stock data available.");

            var latestEntry = stockData.FirstOrDefault();
            if (latestEntry == null) return NotFound("No valid stock data available.");

            var previousEntry = stockData.Skip(1).FirstOrDefault(); // Get previous day's data
            if (previousEntry == null) return NotFound("Not enough data for momentum calculation.");

            var latestSignal = latestStockSignals.FirstOrDefault(s => s.Date == latestEntry.Date);
            var previousSignal = latestStockSignals.FirstOrDefault(s => s.Date == previousEntry.Date);

            if (latestSignal == null || previousSignal == null)
                return NotFound("No valid stock signal for the latest stock data.");

            // ✅ Compute momentum score with improved logic
            int score = 0;
            double closePrice = latestEntry.ClosePrice ?? 0.0;
            double prevClosePrice = previousEntry.ClosePrice ?? 0.0;

            // 1️⃣ ✅ Check if SMA_50 is rising (indicates long-term bullish trend)
            if (latestSignal.SMA_50 > previousSignal.SMA_50) score += 1;

            // 2️⃣ ✅ Check if SMA_10 recently crossed above SMA_50 (bullish crossover)
            bool bullishCrossover = previousSignal.SMA_10 < previousSignal.SMA_50 && latestSignal.SMA_10 > latestSignal.SMA_50;
            if (bullishCrossover) score += 1;

            // 3️⃣ ✅ Check if RSI is rising and moving toward bullish range
            if (latestSignal.RSI > previousSignal.RSI && latestSignal.RSI >= 50 && latestSignal.RSI < 70) score += 1;

            // 4️⃣ ✅ Check if RSI is dropping below 30 (bearish)
            if (latestSignal.RSI < 30 && latestSignal.RSI < previousSignal.RSI) score -= 1;

            return Ok(score);
        }


    }
}
